<?php get_header(); ?>
<div id="volunteer-slogon">
	<div class="volunteer-slogon__background">
		<h2>用爱点亮希望</h2>
	</div>
</div>

<div id="introduce" class="container">
	<h2>雅居乐义工队成立</h2>
	<p>2009年5月12日，雅居乐人以雅居乐义工队的正式宣告成立，由此开启了雅居乐人奉献社会、关爱社区的新征程。</p>
</div>

<?php get_footer(); ?>