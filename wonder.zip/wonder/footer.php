<div id="footer">
    <div class="page-container clearfix">
        <div class="left">
            <p>Copyright © 雅居乐基金会</p>
        </div>
        <div class="right">
            <p><a href="#">粤ICP备05141863号</a></p>
        </div>
    </div>
</div>
<?php wp_footer(); ?>
<script src="<?php bloginfo('template_directory'); ?>/resources/js/jquery-3.3.1.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/resources/js/swiper-4.2.0.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/resources/js/main.js<?php the_wonder_version(); ?>"></script>
<script type="text/javascript" src="http://webapi.amap.com/maps?v=1.3&key=ab3cead0d2621f47b4ee13528c8da7b9&callback=init"></script>
</body>
</html>